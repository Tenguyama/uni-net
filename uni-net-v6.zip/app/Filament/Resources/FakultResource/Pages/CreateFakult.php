<?php

namespace App\Filament\Resources\FakultResource\Pages;

use App\Filament\Resources\FakultResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateFakult extends CreateRecord
{
    protected static string $resource = FakultResource::class;
}
